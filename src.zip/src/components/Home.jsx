import React from 'react'
import { Link, useNavigate } from 'react-router-dom'

function Home() {
    const navigate = useNavigate();

  return (
    <div>
    
      <Link  to='/TodoDetail'  >상세페이지로이동</Link>
    </div>
  )
}

export default Home
