
import Router from "./shered/Router";


const TodoList = ({ item, deleteClick, completeClick }) => {
  return (
    <div className="todo-container" key={item.id}>
      <Router/>
      <div>
        <h2 className="todo-title">{item.todo}</h2>
        <div>{item.list}</div>

      </div>
      <div className="button-set">
   
        <button
          className="todo-delete-button button"
          onClick={() => deleteClick(item.id)}
        >
          삭제하기
        </button>
        <button
          className="todo-complete-button button"
          onClick={() => completeClick(item.id)}
        >
          {item.completed ? "취소" : "완료"}
        </button>
      </div>
    </div>
  );
};

export default TodoList;
