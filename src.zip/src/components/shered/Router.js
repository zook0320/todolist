import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "../Home";
import TodoDetail from "../TodoDetail"; // 새로운 Todo 상세 페이지 컴포넌트를 가져옵니다.

const Router = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="DETAIL_PAGE/:id" element={<TodoDetail />} /> {/* 동적 매개변수 추가 */}
      </Routes>
    </BrowserRouter>
  );
}

export default Router;
